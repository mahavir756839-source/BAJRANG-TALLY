Bajrang Tally - Android Studio project

1. Android Studio me File > Open karo aur ye BajrangTally folder chuno.
2. Gradle sync hone do (pehli baar internet chahiye).
3. Build > Build Bundle(s) / APK(s) > Build APK(s) chuno.
4. Build hone par "locate" par click karo. APK ka path:
   app/build/outputs/apk/debug/app-debug.apk
5. Ye APK phone me bhejkar install karo.

Naya bajrang-tally.html badalna ho to:
app/src/main/assets/bajrang-tally.html ko replace karo, phir dobara Build APK karo.

--- Mobile / bina Android Studio ke ---
GitHub Actions se cloud par APK bana sakte ho:
1. GitHub par free account banao aur ek naya repository (private ya public) banao.
2. Is project ke sab files repository me upload karo (folder structure same rakhna).
3. Repository me "Actions" tab kholo, "Build APK" workflow chalega.
4. Workflow khatam hone par "bajrang-tally-apk" artifact download karo, usme se app-debug.apk nikaal kar install karo.
