package com.example.bajrangtally

import android.os.Bundle
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult
            ): Boolean {
                Toast.makeText(this@MainActivity, message ?: "Bajrang Tally", Toast.LENGTH_LONG).show()
                result.confirm()
                return true
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                Log.e("BajrangTallyJS", "${consoleMessage.message()} (line ${consoleMessage.lineNumber()})")
                return true
            }
        }
        webView.addJavascriptInterface(Bridge(this, webView), "AndroidBridge")
        webView.loadUrl("file:///android_asset/bajrang-tally.html")
        setContentView(webView)
    }
}
