package com.example.bajrangtally

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.FileProvider
import java.io.File

class Bridge(private val activity: Activity, private val webView: WebView) {

    @JavascriptInterface
    fun savePdf(dataUri: String, name: String) {
        val bytes = Base64.decode(dataUri.substringAfter("base64,"), Base64.DEFAULT)
        val file = File(activity.cacheDir, name.replace('/', '-')).apply { writeBytes(bytes) }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        activity.runOnUiThread {
            activity.startActivity(Intent.createChooser(send, name))
        }
    }

    @JavascriptInterface
    fun printPage() {
        activity.runOnUiThread {
            val pm = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("Bajrang Tally", webView.createPrintDocumentAdapter("Bajrang Tally"), PrintAttributes.Builder().build())
        }
    }
}
